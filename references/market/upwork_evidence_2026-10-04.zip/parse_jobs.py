"""Extract pasted Upwork result cards; preserve source lines and original text."""
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ATTACHMENTS = Path('source_inputs')
IDS = [
    'aae31026-0651-40ed-856d-0ecb146ca595',
    'a0f00578-d5fd-4f04-93c5-75917eeb29d1',
    '88ac0d1e-62e0-4f9c-9295-64ce372e32b1',
    '5bab1349-389d-4c71-9b41-cf93132f0115',
    '4a040272-0108-427a-9599-34ae7bd7c295',
    '2613b331-d561-40f3-a76b-ff213caf3f22',
    'fc55b17e-deb0-41c1-81ba-ed8f6e8413dd',
]

def normalized(s):
    return re.sub(r'[^a-z0-9]+', ' ', s.lower()).strip()

cards = []
for file_index, aid in enumerate(IDS, 1):
    path = ATTACHMENTS / aid / 'Pasted text.txt'
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    starts = [i for i, line in enumerate(lines) if line.startswith('Posted ')]
    for index, start in enumerate(starts, 1):
        end = starts[index] if index < len(starts) else next(i for i in range(start, len(lines)) if lines[i].startswith('Jobs Per Page'))
        est = next(i for i in range(start, end) if lines[i].startswith('Est. '))
        description_start = est + 2
        description_end = next((i for i in range(description_start, end) if not lines[i].strip()), end)
        description = '\n'.join(lines[description_start:description_end]).strip()
        skill_tags = [s.strip() for s in lines[description_end:end] if s.strip() and s.strip() not in ('Applied', 'Saved')]
        title_index = start + 1
        if len(lines[title_index].strip()) < 3 or lines[title_index].startswith('Proposals:'):
            title_index = next(i for i in range(start+1, est) if not lines[i].startswith('Proposals:') and len(lines[i].strip())>=3)
        cards.append({
            'source_file_index': file_index,
            'source_attachment_id': aid,
            'source_path': str(path),
            'card_index': index,
            'start_line': start + 1,
            'end_line': end,
            'description_start_line': description_start + 1,
            'description_end_line': description_end,
            'posted_line': lines[start],
            'title': lines[title_index],
            'metadata': lines[start + 2:description_start],
            'description': description,
            'skill_tags': skill_tags,
            'title_key': normalized(lines[title_index]),
            'description_sha256': hashlib.sha256(normalized(description).encode()).hexdigest(),
        })

groups = defaultdict(list)
for card in cards:
    groups[(card['title_key'], card['description_sha256'])].append(card)

jobs = []
for key, group in groups.items():
    first = group[0]
    variants = list(dict.fromkeys(c['description'] for c in group))
    jobs.append({
        'job_id': f'J{len(jobs)+1:03d}',
        'title': first['title'],
        'description': max(variants, key=len),
        'description_variants': variants,
        'duplicate_card_count': len(group),
        'source_cards': [{k: c[k] for k in ('source_file_index','source_attachment_id','source_path','card_index','start_line','end_line','description_start_line','description_end_line','posted_line')} for c in group],
        'skill_tags': list(dict.fromkeys(tag for c in group for tag in c['skill_tags'])),
        'description_chars': len(max(variants, key=len)),
    })

# Manually reviewed same-project reposts identified by extensive distinctive text.
# Preserve original stable IDs; removed IDs remain aliases in the canonical row.
REPOSTS = {'J042': 'J029', 'J068': 'J060'}
by_id={job['job_id']:job for job in jobs}
for alias,canonical in REPOSTS.items():
    target=by_id[canonical]
    duplicate=by_id[alias]
    target.setdefault('merged_job_ids',[]).append(alias)
    target.setdefault('alternate_titles',[]).append(duplicate['title'])
    target['description_variants'].extend(duplicate['description_variants'])
    target['source_cards'].extend(duplicate['source_cards'])
    target['duplicate_card_count']+=duplicate['duplicate_card_count']
    target['skill_tags']=list(dict.fromkeys(target['skill_tags']+duplicate['skill_tags']))
jobs=[job for job in jobs if job['job_id'] not in REPOSTS]

(ROOT / 'pasted_cards.json').write_text(json.dumps(cards, ensure_ascii=False, indent=2), encoding='utf-8')
(ROOT / 'unique_jobs.json').write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding='utf-8')
with (ROOT / 'unique_jobs.csv').open('w', encoding='utf-8-sig', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=['job_id','title','duplicate_card_count','description_chars','source_locations','description'])
    writer.writeheader()
    for job in jobs:
        writer.writerow({k: job[k] for k in ('job_id','title','duplicate_card_count','description_chars','description')} | {'source_locations': '; '.join(f"F{c['source_file_index']}:card{c['card_index']}:lines{c['start_line']}-{c['end_line']}" for c in job['source_cards'])})

summary = {
    'source_files': len(IDS),
    'pasted_cards': len(cards),
    'unique_jobs_exact_title_and_description': len(groups),
    'unique_underlying_projects_after_manually_verified_reposts': len(jobs),
    'manual_repost_merges': REPOSTS,
    'unique_normalized_titles': len(set(c['title_key'] for c in cards)),
    'same_title_different_description': [{'title':cs[0]['title'],'cards':len(cs),'description_count':len(set(c['description_sha256'] for c in cs))} for key,cs in ((key,[c for c in cards if c['title_key']==key]) for key in set(c['title_key'] for c in cards)) if len(set(c['description_sha256'] for c in cs))>1],
    'duplicate_titles': [{'job_id':j['job_id'],'title':j['title'],'cards':j['duplicate_card_count'],'variants':len(j['description_variants'])} for j in jobs if j['duplicate_card_count']>1],
    'different_title_same_description': [{'hash':h,'titles':list(dict.fromkeys(c['title'] for c in cs))} for h,cs in ((h,[c for c in cards if c['description_sha256']==h]) for h in set(c['description_sha256'] for c in cards)) if len(set(c['title_key'] for c in cs))>1],
    'empty_descriptions': [c['title'] for c in cards if not c['description']],
    'descriptions_shorter_than_40': [c['title'] for c in cards if len(c['description'])<40],
    'total_unique_description_chars': sum(j['description_chars'] for j in jobs),
}
(ROOT / 'inventory_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
