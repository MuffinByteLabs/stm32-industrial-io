"""Description/title-only candidate tags, with auditable literal-match evidence.

Counts are explicit mentions in a project's description, not marketplace prevalence.
Manual inclusion/exclusion overrides refine ambiguous matches in tag_overrides.json.
"""
import csv
import json
import re
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
JOBS=json.loads((ROOT/'unique_jobs.json').read_text(encoding='utf-8'))
PATTERNS={
 'stm32': r'\bSTM32\w*',
 'esp32': r'\bESP32\w*',
 'ble_bluetooth': r'\bBLE\b|\bBluetooth\b',
 'wifi': r'\bWi[\W_]?Fi\b|\bWLAN\b',
 'ethernet': r'\bEthernet\b|\bPoE\b',
 'rs485': r'\bRS[\W_]?485\b',
 'modbus': r'\bModbus\b',
 'can': r'\bCAN\b|\bFDCAN\b|\bCANFD\b',
 'can_fd': r'\bCAN[\W_]*FD\b|\bFDCAN\b|\bCANFD\b',
 'adc': r'\bADC\w*\b|\banalog[\W_]+to[\W_]+digital\b',
 'analog_acquisition_conditioning': r'\banalog\b|\bADC\w*\b|\bAFE\b|\bop[\W_]*amp\w*|\bsignal conditioning\b|\bamplifier\b',
 'dac_analog_output': r'\bDAC\w*\b|\banalog output\w*\b|\bdigital[\W_]+to[\W_]+analog\b',
 '4_20ma': r'\b4[\W_]*(?:to[\W_]*)?20[\W_]*mA\b',
 '0_10v': r'\b0[\W_]*(?:to[\W_]*)?10[\W_]*V\b',
 'digital_input': r'\bdigital input\w*\b|\bGPIO\b',
 'input_isolation': r'\bopto\w*|\bisolat\w*',
 'relay': r'\brelay\w*\b',
 'pwm': r'\bPWM\b|\bpulse[\W_]*width modulation\b',
 'motor_driver_hbridge': r'\bmotor\w*\b|\bH[\W_]*bridge\b|\bservo\w*\b|\bBLDC\b|\bstepper\b',
 'battery': r'\bbatter(?:y|ies)\b|\bLi[\W_]*(?:ion|po)\b|\b18650\b|\bBMS\b',
 'battery_charging': r'\bcharg(?:e|ing|er|ers)\b|\bBMS\b',
 'low_power': r'\blow[\W_]+power\b|\bsleep\b|\bultra[\W_]*low\b|\bpower consumption\b|\bpower budget\b',
 '4_layer': r'\b(?:4|four)[\W_]*layer\w*\b|\b2[\W_]+4[\W_]+layer',
 'firmware': r'\bfirmware\b|\bembedded (?:C|software)\b|\bmicrocontroller programming\b',
 'test_bringup': r'\btest\w*\b|\bvalidat\w*\b|\bbring[\W_]*up\b|\bdebug\w*\b|\bprototyp\w*\b',
 'protection': r'\bprotect\w*\b|\bESD\b|\bTVS\b|\bsurge\b|\bover[\W_]*(?:voltage|current|temperature)\b|\breverse polarity\b|\bfuse\w*\b',
 'signal_integrity': r'\bsignal integrity\b|\bcontrolled impedance\b|\bimpedance[\W_]*control\w*\b|\bdifferential pair\w*\b|\breturn (?:path|current)\w*\b|\bcrosstalk\b',
 'emc_emi': r'\bEMC\b|\bEMI\b|\bEMI[\W_]*EMC\b|\bemissions\b|\belectromagnetic\b',
 'manufacturing_handoff': r'\bGerber\w*\b|\bmanufactur\w*\b|\bfabricat\w*\b|\bpick[\W_]*and[\W_]*place\b|\bpick[\W_]*place\b|\bcentroid\b|\bassembly files\b',
 'bom': r'\bBOM\w*\b|\bbill of materials\b',
 'debug_swd_jtag': r'\bSWD\b|\bJTAG\b|\bdebug (?:header|connector|interface|port)\b',
 'testpoints': r'\btest[\W_]*point\w*\b|\btest[\W_]*pad\w*\b',
 'i2c': r'\bI[\W_]*2[\W_]*C\b|\bI²C\b|\bIIC\b',
 'spi': r'\b(?:Q?SPI)\b',
 'uart': r'\bUART\w*\b|\bUSART\w*\b',
 'rtos': r'\b(?:Free|Zephyr)?RTOS\b|\breal[\W_]*time operating system\b',
 'eeprom': r'\bEEPROM\b',
 'data_logging': r'\bdata log\w*\b|\blogging\b|\blogger\b|\blocal storage\b|\btimestamp\w*\b',
 'sd_card': r'\b(?:micro[\W_]*)?SD[\W_]*card\w*\b|\bSDIO\b',
 'usb': r'\bUSB\w*\b',
 'usb_c': r'\bUSB[\W_]*C\b|\bType[\W_]*C\b',
 'power_conversion': r'\bbuck\b|\bboost\b|\bDC[\W_]*DC\b|\bLDO\b|\bregulator\w*\b|\bpower suppl\w*\b|\bpower management\b',
 'sensors': r'\bsensor\w*\b|\bsensing\b|\binstrumentation\b',
 'mechanical_enclosure': r'\benclos\w*\b|\bmechanical\b|\bmounting\b|\bboard dimensions\b',
 'dfm_dfa': r'\bDFM\b|\bDFA\b|\bdesign for (?:manufactur\w*|assembly)\b',
 'drc_erc': r'\bDRC\b|\bERC\b',
 'certification': r'\bFCC\b|\bCE\b|\bUL\b|\bIEC\b|\bcertif\w*\b|\bcompliance\b',
 'mqtt': r'\bMQTT\b',
 'ota': r'\bOTA\b|\bover[\W_]*the[\W_]*air\b',
 'isolated_power': r'\bisolated[\W_]+(?:power|DC|suppl\w*)\b|\bgalvanic isolation\b',
 'gerber': r'\bGerber\w*\b',
 'drill_files': r'\bdrill(?:ing)?[\W_]+(?:files?|outputs?|data)\b|\bNC drill\b',
 'pick_place_centroid': r'\bpick[\W_]*(?:and[\W_]*)?place\b|\bcentroid\b|\bCPL\b|\bP[\W_]*P\b',
 'editable_source_design': r'\beditable\b|\bnative\b|\bsource files\b|\bsource/design files\b|\bPCB source\b|\bschematic source\b|\bPCB sources\b|\bKiCad (?:project|files)\b',
 'bench_test_bringup': r'\bbench[\W_]*test\w*\b|\bbring[\W_]*up\b|\bfunctional[\W_]*(?:test\w*|validat\w*)\b|\bfunction[\W_]*test\w*\b|\btest (?:the |each |of )?(?:PCB|board|prototype|hardware)\w*\b|\btest(?:ing|ed)? (?:prototypes|units|boards|PCBAs)\b|\b(?:PCB|hardware|prototype)[\W_]*(?:testing|validation)\b',
 'calibration': r'\bcalibrat\w*\b',
 'digital_isolated_inputs': r'\bopto[\W_]*isolated (?:digital |24V |24 V )?inputs?\b|\bisolated digital inputs?\b|\bopto[\W_]*coupl\w* inputs?\b',
 'non_audio_analog_sensing': r'(?!)',
 'biomedical_force_analog_sensing': r'(?!)',
 'can_fd_traffic_explicit': r'(?!)',
 'relay_embedded_board': r'(?!)',
}

OVERRIDES=json.loads((ROOT/'tag_overrides.json').read_text(encoding='utf-8')) if (ROOT/'tag_overrides.json').exists() else {}
matches=defaultdict(list)
raw_counts=defaultdict(int)
for job in JOBS:
    value=job['title']+'\n'+job['description']
    job['feature_tags']=[]
    for tag,pattern in PATTERNS.items():
        flags=0 if tag=='can' else re.I
        found=list(re.finditer(pattern,value,flags))
        if found: raw_counts[tag]+=1
        override=OVERRIDES.get(tag,{}).get(job['job_id'])
        if override is not None and not override['include']:
            continue
        if not found and not (override and override['include']):
            continue
        evidence=[{'term':m.group(), 'context':value[max(0,m.start()-110):min(len(value),m.end()+150)]} for m in found]
        matches[tag].append({'job_id':job['job_id'],'title':job['title'],'evidence':evidence,'manual_note':override.get('reason') if override else None})
        job['feature_tags'].append(tag)

(ROOT/'tagged_jobs.json').write_text(json.dumps(JOBS,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'feature_matches.json').write_text(json.dumps(matches,ensure_ascii=False,indent=2),encoding='utf-8')
counts={tag:{'count':len(matches[tag]),'job_ids':[m['job_id'] for m in matches[tag]],'titles':[m['title'] for m in matches[tag]]} for tag in PATTERNS}
(ROOT/'feature_counts.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'feature_raw_mention_counts.json').write_text(json.dumps(raw_counts,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'feature_counts.csv').open('w',encoding='utf-8-sig',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(['feature','count','job_ids'])
    for tag,datum in counts.items(): writer.writerow([tag,datum['count'],'; '.join(datum['job_ids'])])
print('\n'.join(f'{tag}: {data["count"]}' for tag,data in counts.items()))
